from flask import Blueprint, render_template, request, jsonify, flash, redirect, url_for
from flask_login import login_required, current_user
from models import db, Carga, SubCarga, Usuario, ConfiguracaoFormulario, Producao, Fechamento, TipoUsuario, HistoricoCarga
from datetime import datetime
from constants import *
from extensions import csrf
from routes.notificacoes import notificar_nova_carga, notificar_producao, notificar_fechamento
from utils import (permissao_balanca, permissao_producao, permissao_fechamento, 
                  permissao_financeiro, permissao_diretoria, permissao_gerente)

cargas = Blueprint('cargas', __name__)

# Marcar rotas como isentas de CSRF
csrf.exempt(cargas)

@cargas.route('/nova_carga', methods=['GET'])
@login_required
@permissao_balanca
def nova_carga():
    configuracoes = ConfiguracaoFormulario.query.order_by(ConfiguracaoFormulario.ordem).all()
    return render_template('cargas/nova_carga.html',
                         tipos_ave=TIPOS_AVE,
                         motoristas=MOTORISTAS,
                         transportadoras=TRANSPORTADORAS,
                         placas_ellen=PLACAS_ELLEN,
                         valores_km=VALORES_KM,
                         status_frete=STATUS_FRETE,
                         estados_brasil=ESTADOS_BRASIL,
                         configuracoes=configuracoes)

@cargas.route('/criar_carga', methods=['POST'])
@login_required
@permissao_balanca
def criar_carga():
    try:
        data = request.json
        print("Dados recebidos:", data)  # Log dos dados recebidos

        # Gerar número da carga
        ultima_carga = Carga.query.order_by(Carga.numero_carga.desc()).first()
        if ultima_carga:
            try:
                ultimo_numero = int(ultima_carga.numero_carga)
                numero_carga = ultimo_numero + 1
            except (ValueError, TypeError):
                numero_carga = NUMERO_INICIAL_CARGA
        else:
            numero_carga = NUMERO_INICIAL_CARGA
        print("Número da carga gerado:", numero_carga)  # Log do número da carga

        # Criar a carga
        carga = Carga(
            numero_carga=str(numero_carga),
            tipo_ave=data.get('tipo_ave'),
            quantidade_cargas=data.get('quantidade_cargas'),
            ordem_carga=data.get('ordem_carga'),
            data_abate=datetime.strptime(data.get('data_abate'), '%Y-%m-%d').date(),
            dia_semana=data.get('dia_semana'),
            agenciador=data.get('agenciador'),
            motorista=data.get('motorista'),
            motorista_outro=data.get('motorista_outro'),
            transportadora=data.get('transportadora'),
            placa_veiculo=data.get('placa_veiculo'),
            km_saida=float(data.get('km_saida', 0)),
            valor_km=float(data.get('valor_km', 0)),
            status_frete=data.get('status_frete'),
            criado_por_id=current_user.id,
            atualizado_por_id=current_user.id
        )
        
        db.session.add(carga)
        db.session.commit()
        
        # Registrar no histórico
        registrar_historico(carga.id, f"Criou a carga #{carga.numero_carga}")
        
        # Notificar usuários
        notificar_nova_carga(carga)
        
        return jsonify({
            'success': True,
            'message': 'Carga criada com sucesso!',
            'id': carga.id
        })
    except Exception as e:
        print(f"Erro ao criar carga: {str(e)}")
        return jsonify({
            'success': False,
            'message': f'Erro ao criar carga: {str(e)}'
        }), 500

@cargas.route('/fechamento')
@login_required
def fechamento_carga():
    return render_template('cargas/fechamento_carga.html')

@cargas.route('/buscar_carga_fechamento/<numero_carga>')
@login_required
@permissao_fechamento
def buscar_carga_fechamento(numero_carga):
    try:
        carga = Carga.query.filter_by(numero_carga=numero_carga).first()
        if not carga:
            return jsonify({'success': False, 'message': 'Carga não encontrada'})

        # Verificar se a carga já tem fechamento
        fechamento_data = None
        if carga.fechamento:
            fechamento_data = {
                'tratativas': carga.fechamento.tratativas,
                'tipo_fechamento_1': carga.fechamento.tipo_fechamento_1,
                'quantidade_1': carga.fechamento.quantidade_1,
                'valor_unitario_1': carga.fechamento.valor_unitario_1,
                'descontos_1': carga.fechamento.descontos_1,
                'valor_total_1': carga.fechamento.valor_total_1,
                'observacoes_1': carga.fechamento.observacoes_1
            }
            if carga.fechamento.tratativas == '2':
                fechamento_data.update({
                    'tipo_fechamento_2': carga.fechamento.tipo_fechamento_2,
                    'quantidade_2': carga.fechamento.quantidade_2,
                    'valor_unitario_2': carga.fechamento.valor_unitario_2,
                    'descontos_2': carga.fechamento.descontos_2,
                    'valor_total_2': carga.fechamento.valor_total_2,
                    'observacoes_2': carga.fechamento.observacoes_2
                })

        return jsonify({
            'success': True,
            'data': {
                'carga': {
                    'numero_carga': carga.numero_carga,
                    'tipo_ave': carga.tipo_ave,
                    'quantidade_cargas': carga.quantidade_cargas,
                    'motorista': carga.motorista,
                    'motorista_outro': carga.motorista_outro,
                    'transportadora': carga.transportadora,
                    'placa_veiculo': carga.placa_veiculo,
                    'km_rodados': carga.km_rodados,
                    'valor_km': carga.valor_km,
                    'valor_frete': carga.valor_frete,
                    'pedagios': carga.pedagios,
                    'outras_despesas': carga.outras_despesas,
                    'abastecimento_empresa': carga.abastecimento_empresa,
                    'abastecimento_posto': carga.abastecimento_posto,
                    'adiantamento': carga.adiantamento,
                    'valor_pagar': carga.valor_pagar
                },
                'fechamento': fechamento_data
            }
        })
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)})

@cargas.route('/salvar_fechamento', methods=['POST'])
@login_required
@permissao_fechamento
def salvar_fechamento():
    dados = request.get_json()
    
    # Buscar a carga pelo número
    numero_carga = dados.pop('numero_carga')  # Remove e retorna o numero_carga dos dados
    carga = Carga.query.filter_by(numero_carga=numero_carga).first()
    if not carga:
        return jsonify({'success': False, 'message': 'Carga não encontrada'})
    
    try:
        # Converter strings para float
        for campo in ['quantidade_1', 'valor_unitario_1', 'descontos_1', 'valor_total_1']:
            if campo in dados:
                dados[campo] = float(dados[campo])
        
        if dados['tratativas'] == '2':
            for campo in ['quantidade_2', 'valor_unitario_2', 'descontos_2', 'valor_total_2']:
                if campo in dados:
                    dados[campo] = float(dados[campo])
        
        # Se já existe um fechamento, atualizar
        if carga.fechamento:
            fechamento = carga.fechamento
            for key, value in dados.items():
                setattr(fechamento, key, value)
        else:
            # Criar novo fechamento
            fechamento = Fechamento(**dados)
            fechamento.carga = carga
            db.session.add(fechamento)
        
        db.session.commit()
        
        # Registrar no histórico
        registrar_historico(carga.id, f"Registrou fechamento da carga #{carga.numero_carga}")
        
        # Notificar gerentes sobre fechamento inserido
        notificar_fechamento(carga)
        
        return jsonify({'success': True})
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'message': str(e)})

@cargas.route('/cargas_incompletas')
@login_required
def cargas_incompletas():
    cargas = Carga.query.filter_by(status='incompleto').all()
    return render_template('cargas/cargas_incompletas.html', cargas=cargas)

@cargas.route('/todas_cargas')
@login_required
def todas_cargas():
    cargas = Carga.query.order_by(Carga.criado_em.desc()).all()
    return render_template('cargas/todas_cargas.html', cargas=cargas)

def registrar_historico(carga_id, acao):
    """Registra uma ação no histórico da carga"""
    historico = HistoricoCarga(
        carga_id=carga_id,
        usuario_id=current_user.id,
        acao=acao
    )
    db.session.add(historico)
    db.session.commit()

@cargas.route('/historico/<int:id>')
@login_required
def historico_carga(id):
    carga = Carga.query.get_or_404(id)
    historicos = HistoricoCarga.query\
        .filter_by(carga_id=id)\
        .order_by(HistoricoCarga.data_hora.desc())\
        .all()
    return render_template('cargas/historico.html', carga=carga, historicos=historicos)

@cargas.route('/visualizar/<int:id>')
@login_required
def visualizar_carga(id):
    carga = Carga.query.get_or_404(id)
    registrar_historico(id, f"Visualizou a carga #{carga.numero_carga}")
    producao = Producao.query.filter_by(carga_id=id).first()
    return render_template('cargas/visualizar_carga.html', carga=carga, producao=producao)

@cargas.route('/editar/<int:id>', methods=['GET'])
@login_required
@permissao_balanca
def editar_carga(id):
    carga = Carga.query.get_or_404(id)
    configuracoes = ConfiguracaoFormulario.query.order_by(ConfiguracaoFormulario.ordem).all()
    return render_template('cargas/editar_carga.html', 
                         carga=carga,
                         tipos_ave=TIPOS_AVE,
                         motoristas=MOTORISTAS,
                         transportadoras=TRANSPORTADORAS,
                         placas_ellen=PLACAS_ELLEN,
                         valores_km=VALORES_KM,
                         status_frete=STATUS_FRETE,
                         estados_brasil=ESTADOS_BRASIL,
                         configuracoes=configuracoes)

@cargas.route('/atualizar_carga/<int:id>', methods=['POST'])
@login_required
@permissao_balanca
def atualizar_carga(id):
    try:
        carga = Carga.query.get_or_404(id)
        data = request.json

        # Atualizar campos da carga
        for campo, valor in data.items():
            if hasattr(carga, campo):
                setattr(carga, campo, valor)
        
        carga.atualizado_por_id = current_user.id
        carga.atualizado_em = datetime.now()
        
        db.session.commit()
        
        # Registrar no histórico
        registrar_historico(id, f"Atualizou a carga #{carga.numero_carga}")
        
        return jsonify({
            'success': True,
            'message': 'Carga atualizada com sucesso!'
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'message': f'Erro ao atualizar carga: {str(e)}'
        }), 500

@cargas.route('/')
@login_required
def listar_cargas():
    cargas = Carga.query.order_by(Carga.criado_em.desc()).all()
    return render_template('cargas/listar_cargas.html', cargas=cargas)

@cargas.route('/producao')
@login_required
@permissao_producao
def producao():
    return render_template('cargas/producao.html')

@cargas.route('/producao/buscar/<numero_carga>')
@login_required
@permissao_producao
def buscar_carga_producao(numero_carga):
    carga = Carga.query.filter_by(numero_carga=numero_carga).first()
    if not carga:
        return jsonify({'success': False, 'message': 'Carga não encontrada'}), 404
    
    return jsonify({
        'success': True,
        'carga': {
            'id': carga.id,
            'numero_carga': carga.numero_carga,
            'tipo_ave': carga.tipo_ave,
            'data_abate': carga.data_abate.strftime('%Y-%m-%d'),
            'motorista': carga.motorista
        }
    })

@cargas.route('/producao/salvar', methods=['POST'])
@login_required
@permissao_producao
def salvar_producao():
    try:
        data = request.json
        carga = Carga.query.get_or_404(data['carga_id'])
        
        producao = Producao(
            carga_id=carga.id,
            data_producao=datetime.strptime(data['data_producao'], '%Y-%m-%d').date(),
            aves_granja=int(data['aves_granja']),
            aves_mortas=int(data['aves_mortas']),
            aves_recebidas=int(data['aves_recebidas']),
            aves_contador=int(data['aves_contador']),
            aves_por_caixa=int(data['aves_por_caixa']),
            mortalidade_excesso=float(data['mortalidade_excesso']),
            aves_molhadas_granja=float(data['aves_molhadas_granja']),
            aves_molhadas_chuva=float(data['aves_molhadas_chuva']),
            quebra_maus_tratos=float(data['quebra_maus_tratos']),
            aves_papo_cheio=float(data['aves_papo_cheio']),
            outras_quebras=float(data['outras_quebras']),
            descricao_quebras=data['descricao_quebras'],
            total_avarias=float(data['total_avarias'])
        )
        
        db.session.add(producao)
        db.session.commit()
        
        # Registrar no histórico
        registrar_historico(carga.id, f"Registrou dados de produção da carga #{carga.numero_carga}")
        
        # Notificar gerentes sobre produção inserida
        notificar_producao(carga)
        
        return jsonify({
            'success': True,
            'message': 'Dados de produção salvos com sucesso!'
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'message': f'Erro ao salvar dados de produção: {str(e)}'
        }), 500

@cargas.route('/solicitar_verificacao/<int:id>', methods=['POST'])
@login_required
@permissao_financeiro
def solicitar_verificacao(id):
    try:
        carga = Carga.query.get_or_404(id)
        motivo = request.json.get('motivo', '')
        
        # Registrar no histórico
        registrar_historico(id, f"Solicitou verificação da carga #{carga.numero_carga}. Motivo: {motivo}")
        
        return jsonify({
            'success': True,
            'message': 'Solicitação de verificação enviada com sucesso!'
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'message': f'Erro ao solicitar verificação: {str(e)}'
        }), 500

@cargas.route('/solicitar_exclusao/<int:id>', methods=['POST'])
@login_required
@permissao_financeiro
def solicitar_exclusao(id):
    try:
        carga = Carga.query.get_or_404(id)
        motivo = request.json.get('motivo', '')
        
        # Registrar no histórico
        registrar_historico(id, f"Solicitou exclusão da carga #{carga.numero_carga}. Motivo: {motivo}")
        
        return jsonify({
            'success': True,
            'message': 'Solicitação de exclusão enviada com sucesso!'
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'message': f'Erro ao solicitar exclusão: {str(e)}'
        }), 500

@cargas.route('/aprovar_nota/<int:id>', methods=['POST'])
@login_required
@permissao_financeiro
def aprovar_nota(id):
    try:
        carga = Carga.query.get_or_404(id)
        
        if carga.nota_aprovada:
            return jsonify({
                'success': False,
                'message': 'Esta nota já foi aprovada!'
            }), 400
        
        carga.nota_aprovada = True
        carga.aprovado_por_id = current_user.id
        carga.aprovado_em = datetime.now()
        
        db.session.commit()
        
        # Registrar no histórico
        registrar_historico(id, f"Aprovou a nota da carga #{carga.numero_carga}")
        
        return jsonify({
            'success': True,
            'message': 'Nota aprovada com sucesso!'
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'message': f'Erro ao aprovar nota: {str(e)}'
        }), 500

@cargas.route('/autorizar_nota/<int:id>', methods=['POST'])
@login_required
@permissao_diretoria
def autorizar_nota(id):
    try:
        carga = Carga.query.get_or_404(id)
        data = request.json
        
        if not carga.nota_aprovada:
            return jsonify({
                'success': False,
                'message': 'A nota precisa ser aprovada antes de ser autorizada!'
            }), 400
            
        if carga.nota_autorizada:
            return jsonify({
                'success': False,
                'message': 'Esta nota já foi autorizada!'
            }), 400
        
        carga.nota_autorizada = True
        carga.autorizado_por_id = current_user.id
        carga.autorizado_em = datetime.now()
        carga.assinatura_autorizacao = data.get('assinatura')
        
        db.session.commit()
        
        # Registrar no histórico
        registrar_historico(id, f"Autorizou a nota da carga #{carga.numero_carga}")
        
        return jsonify({
            'success': True,
            'message': 'Nota autorizada com sucesso!'
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'message': f'Erro ao autorizar nota: {str(e)}'
        }), 500

@cargas.route('/solicitar_verificacao_balanca/<int:id>', methods=['POST'])
@login_required
@permissao_balanca
def solicitar_verificacao_balanca(id):
    try:
        carga = Carga.query.get_or_404(id)
        motivo = request.json.get('motivo', '')
        
        carga.status_balanca = 'em_verificacao'
        carga.motivo_verificacao_balanca = motivo
        carga.data_verificacao_balanca = datetime.now()
        
        db.session.commit()
        
        # Registrar no histórico
        registrar_historico(id, f"Solicitou verificação da balança para carga #{carga.numero_carga}. Motivo: {motivo}")
        
        return jsonify({
            'success': True,
            'message': 'Solicitação de verificação enviada com sucesso!'
        })
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'message': f'Erro ao solicitar verificação: {str(e)}'
        }), 500

@cargas.route('/solicitar_verificacao_producao/<int:id>', methods=['POST'])
@login_required
@permissao_producao
def solicitar_verificacao_producao(id):
    try:
        carga = Carga.query.get_or_404(id)
        motivo = request.json.get('motivo', '')
        
        carga.status_producao = 'em_verificacao'
        carga.motivo_verificacao_producao = motivo
        carga.data_verificacao_producao = datetime.now()
        
        db.session.commit()
        
        # Registrar no histórico
        registrar_historico(id, f"Solicitou verificação da produção para carga #{carga.numero_carga}. Motivo: {motivo}")
        
        return jsonify({
            'success': True,
            'message': 'Solicitação de verificação enviada com sucesso!'
        })
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'message': f'Erro ao solicitar verificação: {str(e)}'
        }), 500

@cargas.route('/solicitar_verificacao_fechamento/<int:id>', methods=['POST'])
@login_required
@permissao_fechamento
def solicitar_verificacao_fechamento(id):
    try:
        carga = Carga.query.get_or_404(id)
        motivo = request.json.get('motivo', '')
        
        carga.status_fechamento = 'em_verificacao'
        carga.motivo_verificacao_fechamento = motivo
        carga.data_verificacao_fechamento = datetime.now()
        
        db.session.commit()
        
        # Registrar no histórico
        registrar_historico(id, f"Solicitou verificação do fechamento para carga #{carga.numero_carga}. Motivo: {motivo}")
        
        return jsonify({
            'success': True,
            'message': 'Solicitação de verificação enviada com sucesso!'
        })
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'message': f'Erro ao solicitar verificação: {str(e)}'
        }), 500

@cargas.route('/aprovar_verificacao_balanca/<int:id>', methods=['POST'])
@login_required
@permissao_gerente
def aprovar_verificacao_balanca(id):
    try:
        carga = Carga.query.get_or_404(id)
        
        carga.status_balanca = 'aprovado'
        carga.verificado_por_balanca_id = current_user.id
        
        db.session.commit()
        
        # Registrar no histórico
        registrar_historico(id, f"Aprovou verificação da balança para carga #{carga.numero_carga}")
        
        return jsonify({
            'success': True,
            'message': 'Verificação aprovada com sucesso!'
        })
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'message': f'Erro ao aprovar verificação: {str(e)}'
        }), 500

@cargas.route('/aprovar_verificacao_producao/<int:id>', methods=['POST'])
@login_required
@permissao_gerente
def aprovar_verificacao_producao(id):
    try:
        carga = Carga.query.get_or_404(id)
        
        carga.status_producao = 'aprovado'
        carga.verificado_por_producao_id = current_user.id
        
        db.session.commit()
        
        # Registrar no histórico
        registrar_historico(id, f"Aprovou verificação da produção para carga #{carga.numero_carga}")
        
        return jsonify({
            'success': True,
            'message': 'Verificação aprovada com sucesso!'
        })
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'message': f'Erro ao aprovar verificação: {str(e)}'
        }), 500

@cargas.route('/aprovar_verificacao_fechamento/<int:id>', methods=['POST'])
@login_required
@permissao_gerente
def aprovar_verificacao_fechamento(id):
    try:
        carga = Carga.query.get_or_404(id)
        
        carga.status_fechamento = 'aprovado'
        carga.verificado_por_fechamento_id = current_user.id
        
        db.session.commit()
        
        # Registrar no histórico
        registrar_historico(id, f"Aprovou verificação do fechamento para carga #{carga.numero_carga}")
        
        return jsonify({
            'success': True,
            'message': 'Verificação aprovada com sucesso!'
        })
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'message': f'Erro ao aprovar verificação: {str(e)}'
        }), 500
