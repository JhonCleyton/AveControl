# Este arquivo pode ficar vazio
# Os blueprints são registrados diretamente no app.py
